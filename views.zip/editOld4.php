<?php
if(!empty($list_laporan_cmInfo))
{
    foreach ($list_laporan_cmInfo as $v_ri)
    {
        $id=$v_ri->id;
        $id_atm=$v_ri->id_atm;
        $wilayah=$v_ri->wilayah;
        $cabang_pemilik=$v_ri->cabang_pemilik;
        $lokasi=$v_ri->lokasi;
        $jenis_mesin=$v_ri->jenis_mesin;
        $tipe_mesin=$v_ri->tipe_mesin;
        $serial_mesin=$v_ri->serial_mesin;
        $flm=$v_ri->flm;
        $nama_pt_slm=$v_ri->nama_pt_slm;        
        $nama_petugas_flm=$v_ri->nama_petugas_flm;
        $npp=$v_ri->npp;
        $no_tiket=$v_ri->no_tiket;
        $keterangan_cm=$v_ri->keterangan_cm;
        $tgl_kunjungan_flm=$v_ri->tgl_kunjungan_flm;
        $jam_kunjungan_flm=$v_ri->jam_kunjungan_flm;
        $pihak_yang_melakukan_kunjungan=$v_ri->pihak_yang_melakukan_kunjungan;
        $nama_petugas_slm=$v_ri->nama_petugas_slm;
        $kondisi_kamera_cctv_dvr=$v_ri->kondisi_kamera_cctv_dvr;
        $kondisi_ups=$v_ri->kondisi_ups;
        $tegangan=$v_ri->tegangan;
        $ground=$v_ri->ground;
        $suhu_ruang=$v_ri->suhu_ruang;
        $tindakan=$v_ri->tindakan;
        $spare_part_yang_diganti=$v_ri->spare_part_yang_diganti;
        $versi_image=$v_ri->versi_image;
        $tgl_kunjungan_slm=$v_ri->tgl_kunjungan_slm;
        $jam_kunjungan_slm=$v_ri->jam_kunjungan_slm;


    }
}
?>
<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/smoothness/jquery-ui.css" >
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i> List Laporan CM Management
        <small>Add / Edit List Laporan CM</small>
      </h1>
    </section>
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter List Laporan CM Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>editlist_laporan_cm" method="post" id="editlist_laporan_cm" role="form">
                        <div class="box-body">
                            <div class="row">
                               <div class="col-md-6">                     <div hidden class="form-group">
                                        <label for="id">List Laporan ID</label>
                                        <br>
                                        <input type="text" class="form-control" id="id" placeholder="id" name="id" value="<?php echo $id; ?>" maxlength="128">
                                    </div>
                                    
            
                                    <div class="form-group">
                                        <label for="id_atm">ID ATM</label>
                                        <input readonly type="text" class="form-control" id="id_atm" placeholder="id_atm" name="id_atm" value="<?php echo $id_atm; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="wilayah">Wilayah</label>
                                        <input readonly type="text" class="form-control" id="wilayah" placeholder="wilayah" name="wilayah" value="<?php echo $wilayah; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="cabang_pemilik">Cabang Pemilik</label>
                                        <input readonly type="text" class="form-control" id="cabang_pemilik" placeholder="cabang_pemilik" name="cabang_pemilik" value="<?php echo $cabang_pemilik; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="lokasi">Lokasi</label>
                                        <input readonly type="text" class="form-control" id="lokasi" placeholder="lokasi" name="lokasi" value="<?php echo $lokasi; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="jenis_mesin">Jenis mesin</label>
                                        <input readonly type="text" class="form-control" id="jenis_mesin" placeholder="jenis_mesin" name="jenis_mesin" value="<?php echo $jenis_mesin; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="tipe_mesin">Tipe Mesin</label>
                                        <input readonly type="text" class="form-control" id="tipe_mesin" placeholder="tipe_mesin" name="tipe_mesin" value="<?php echo $tipe_mesin; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="serial_mesin">Serial Mesin</label>
                                        <input readonly type="text" class="form-control" id="serial_mesin" placeholder="serial_mesin" name="serial_mesin" value="<?php echo $serial_mesin; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="flm">FLM</label>
                                        <input readonly type="text" class="form-control" id="flm" placeholder="flm" name="flm" value="<?php echo $flm; ?>" maxlength="128">
                                    </div>
                                   <div class="form-group">
                                        <label for="nama_pt_slm">Nama PT SLM</label>
                                        <input readonly type="text" class="form-control" id="nama_pt_slm" placeholder="nama_pt_slm" name="nama_pt_slm" value="<?php echo $nama_pt_slm; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="nama_petugas_flm">Nama Petugas FLM</label>
                                        <input readonly type="text" class="form-control" id="nama_petugas_flm" placeholder="nama_petugas_flm" name="nama_petugas_flm" value="<?php echo $nama_petugas_flm; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="npp">NPP</label>
                                        <input readonly type="text" class="form-control" id="npp" placeholder="npp" name="npp" value="<?php echo $npp; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="no_tiket">No Tiket</label>
                                        <input type="text" class="form-control" id="no_tiket" placeholder="no_tiket" name="no_tiket" value="<?php echo $no_tiket; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="keterangan_cm">No Tiket</label>
                                        <input type="text" class="form-control" id="keterangan_cm" placeholder="keterangan_cm" name="keterangan_cm" value="<?php echo $keterangan_cm; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="tgl_kunjungan_flm">Tgl Kunjungan FLM</label>
                                        <input readonly type="text" class="form-control" id="tgl_kunjungan_flm" placeholder="tgl_kunjungan_flm" name="tgl_kunjungan_flm" value="<?php echo $tgl_kunjungan_flm; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="jam_kunjungan_flm">Jam Kunjungan FLM</label>
                                        <input readonly type="text" class="form-control" id="jam_kunjungan_flm" placeholder="jam_kunjungan_flm" name="jam_kunjungan_flm" value="<?php echo $jam_kunjungan_flm; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="pihak_yang_melakukan_kunjungan">Pihak Yang Melakukan Kunjungan</label>
                                        <input readonly type="text" class="form-control" id="pihak_yang_melakukan_kunjungan" placeholder="pihak_yang_melakukan_kunjungan" name="pihak_yang_melakukan_kunjungan" value="<?php echo $pihak_yang_melakukan_kunjungan; ?>" maxlength="128">
                                    </div>                     
                                </div>
                               <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="nama_petugas_slm">Nama Petugas SLM</label>
                                        <input required type="text" class="form-control" id="nama_petugas_slm" placeholder="nama_petugas_slm" name="nama_petugas_slm" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="merk_cctv">Merk CCTV</label>
                                        <input required type="text" class="form-control" id="merk_cctv" placeholder="merk_cctv" name="merk_cctv" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="serial_number_cctv">Serial Number CCTV</label>
                                        <input required type="text" class="form-control" id="serial_number_cctv" placeholder="serial_number_cctv" name="serial_number_cctv" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="kondisi_kamera_cctv_dvr">Kondisi Kamera CCTV/DVR</label>
                                        <select required name="kondisi_kamera_cctv_dvr" class="form-control select2" style="width: 100%;">
                                         <option value="Berfungsi Normal">Berfungsi Normal</option>
                                         <option value="Rusak">Rusak</option>
                                       </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="merk_ups">Merk UPS</label>
                                        <input required type="text" class="form-control" id="merk_ups" placeholder="merk_ups" name="merk_ups" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="serial_number_ups">Serial Number UPS</label>
                                        <input required type="text" class="form-control" id="serial_number_ups" placeholder="serial_number_ups" name="serial_number_ups" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="kondisi_ups">Kondisi UPS</label>
                                        <select required name="kondisi_ups" class="form-control select2" style="width: 100%;">
                                         <option value="Berfungsi Normal">Berfungsi Normal</option>
                                         <option value="Rusak">Rusak</option>
                                       </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="tegangan">Tegangan</label>
                                        <input required type="text" class="form-control" id="tegangan" placeholder="tegangan" name="tegangan" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="ground">Ground</label>
                                        <input required type="text" class="form-control" id="ground" placeholder="ground" name="ground" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="suhu_ruang">Suhu Ruang</label>
                                        <input required type="text" class="form-control" id="suhu_ruang" placeholder="suhu_ruang" name="suhu_ruang" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="tindakan">Tindakan</label>
                                        <input required type="text" class="form-control" id="tindakan" placeholder="tindakan" name="tindakan" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="spare_part_yang_diganti">Spare Part Yang Diganti</label>
                                        <select required name="spare_part_yang_diganti_select" class="form-control select2" style="width: 100%;">
                                            <option value="Diganti">Diganti</option>
                                            <option value="Tidak DIganti">Tidak Diganti</option>
                                       </select>
                                        <input required type="text" class="form-control" id="spare_part_yang_diganti" placeholder="spare_part_yang_diganti" name="spare_part_yang_diganti" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="versi_image">Versi Image</label>
                                        <select required name="versi_image" class="form-control select2" style="width: 100%;">
                                            <option value="BNI_MP_PC1500_SINGLECAM_V.5.1_NOWL.GHO">BNI_MP_PC1500_SINGLECAM_V.5.1_NOWL.GHO</option>
                                            <option value="BNI_MP_PC1500_SINGLECAM_V.5.1_WL.GHO">BNI_MP_PC1500_SINGLECAM_V.5.1_WL.GHO</option>
                                            <option value="BNI_PC1500XEUSB_v2.1.GHO">BNI_PC1500XEUSB_v2.1.GHO</option>
                                            <option value="BNI_PC1500XEUSB_v3.1.GHO ">BNI_PC1500XEUSB_v3.1.GHO </option>
                                            <option value="BNI_PC1500XEUSB_v4.1.GHO">BNI_PC1500XEUSB_v4.1.GHO</option>
                                            <option value="BNI_MP_PC1500xeUSB_V2.1.GHO">BNI_MP_PC1500xeUSB_V2.1.GHO</option>
                                            <option value="BNI_MP_PC280_NOWL_V1.4.GHO">BNI_MP_PC280_NOWL_V1.4.GHO</option>
                                            <option value="BNI_MP_PC280_WL_V2.6.GHO">BNI_MP_PC280_WL_V2.6.GHO</option>
                                            <option value="BNI_MP_PC280_V3.2.GHO">BNI_MP_PC280_V3.2.GHO</option>
                                            <option value="BNI_MP_PC280N_TALKING_V1.5.GHO">BNI_MP_PC280N_TALKING_V1.5.GHO</option>
                                            <option value="BNI_MP_PC280N_V1.8.GHO">BNI_MP_PC280N_V1.8.GHO</option>
                                            <option value="BNI_PC280N_V1.5.GHO [non Mp]">BNI_PC280N_V1.5.GHO [non Mp]</option>
                                            <option value="BNI_MP_PC285_V1.4.GHO">BNI_MP_PC285_V1.4.GHO</option>
                                            <option value="BNI_PC280N_WL_V2.8.GHO [non Mp]">BNI_PC280N_WL_V2.8.GHO [non Mp]</option>
                                            <option value="BNI_PC280N_V2.8.GHO [non Mp]">BNI_PC280N_V2.8.GHO [non Mp]</option>
                                            <option value="BNI_MP_PC280N_WL_V2.8.GHO">BNI_MP_PC280N_WL_V2.8.GHO</option>
                                            <option value="BNI_MP_PC280N_V2.8.GHO">BNI_MP_PC280N_V2.8.GHO</option>
                                            <option value="BNI_CRMOKI_RG7+_2017_V6.0 / 02.00.17.029.016">BNI_CRMOKI_RG7+_2017_V6.0 / 02.00.17.029.016</option>
                                            <option value="BNI CRM-EMV V1.4.4">BNI CRM-EMV V1.4.4</option>
                                            <option value="BNI_HYO_MX5600MP_2015_V 3.0">BNI_HYO_MX5600MP_2015_V 3.0</option>
                                            <option value="BNI_HYO_CRM8600_2016.V5.0">BNI_HYO_CRM8600_2016.V5.0</option>
                                            <option value="BNI_HYOSUNG_MX8600S_2017_V4.0 ">BNI_HYOSUNG_MX8600S_2017_V4.0 </option>
                                            <option value="BNI_HYOSUNG_MX8600S_2018_V2.0 ">BNI_HYOSUNG_MX8600S_2018_V2.0 </option>
                                            <option value="V 02.03.03.05 TARGETED_1B">V 02.03.03.05 TARGETED_1B</option>
                                            <option value="Aptra 6.1">Aptra 6.1</option>
                                            <option value="Aptra 5.1">Aptra 5.1</option>
                                            <option value="BNI Denver_Agilis_Ndx_xv211_ver136">BNI Denver_Agilis_Ndx_xv211_ver136</option>
                                            <option value="BNI_522_sierra_empower30_ndx_sp0_v1_5_1">BNI_522_sierra_empower30_ndx_sp0_v1_5_1</option>

                                       </select>
                                    </div>                      
                               </div>
                            </div>
                        </div><!-- /.box-body -->
    
    
                        <div class="box-footer">
                        <a href="<?php echo base_url(); ?>list_laporan_cmListing"> 
                        <button class="btn btn-danger">Back</BUTTON>
                        </a> 
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>

<script src="<?php echo base_url(); ?>assets/js/editUser.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/js/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
    <script>
    $(document).ready(function(){ // Ketika halaman selesai di load
        $('.input-tanggal').datepicker({
            dateFormat: 'yy-mm-dd' // Set format tanggalnya jadi yyyy-mm-dd
        });

        $('#form-tanggal, #form-bulan, #form-tahun').hide(); // Sebagai default klist_laporan_cm sembunyikan form filter tanggal, bulan & tahunnya

        $('#filter').change(function(){ // Ketika user memilih filter
            if($(this).val() == '1'){ // Jika filter nya 1 (per tanggal)
                $('#form-bulan, #form-tahun').hide(); // Sembunyikan form bulan dan tahun
                $('#form-tanggal').show(); // Tampilkan form tanggal
            }else if($(this).val() == '2'){ // Jika filter nya 2 (per bulan)
                $('#form-tanggal').hide(); // Sembunyikan form tanggal
                $('#form-bulan, #form-tahun').show(); // Tampilkan form bulan dan tahun
            }else{ // Jika filternya 3 (per tahun)
                $('#form-tanggal, #form-bulan').hide(); // Sembunyikan form tanggal dan bulan
                $('#form-tahun').show(); // Tampilkan form tahun
            }

            $('#form-tanggal input, #form-bulan select, #form-tahun select').val(''); // Clear data pada textbox tanggal, combobox bulan & tahun
        })
      
    })

  </script>