<?php 


$page = "http://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI']; 
$page = str_replace("http://172.18.22.51/list_laporan_cm/list_laporan_cmListing", "", $page);
?>

<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/smoothness/jquery-ui.css" >
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h4>
        </i> Laporan CM
      </h4>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <div class="form-group">
                      <div class="box-tools">
                        <form action="<?php echo base_url() ?>list_laporan_cmListing" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="id_atmText" value="<?php echo $id_atmText; ?>"  style="width: 150px;" placeholder="ID ATM"/>
                              <input type="text" name="statusText" value="<?php echo $statusText; ?>"  style="width: 150px;" placeholder="Status"/>
                              <input type="text" name="ket_statusText" value="<?php echo $ket_statusText; ?>"  style="width: 150px;" placeholder="Ket Status"/>
                              <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                            </div>
                        </form>
                    </div>

<div class="box-body table-responsive no-padding">
                  <table class="table table-hover">
                    <tr>
                      <th>Edit</th>
                      <th>Status</th>
                      <th>Ket Status</th>
                      <th>ID ATM</th>
                      <th>Wilayah</th>
                      <th>Cabang Pemilik</th>
                      <th>Lokasi</th>
                      <th>Jenis Mesin</th>
                      <th>Tipe Mesin</th>
                      <th>Serial Mesin</th>
                      <th>FLM</th>
                      <th>Nama PT SLM</th>
                      <th>Nama Petugas FLM</th>
                      <th>NPP</th>
                      <th>No Tiket</th>
                      <th>Keterangan CM</th>
                      <th>Tgl Kunjungan FLM</th>
                      <th>Jam Kunjungan FLM</th>
                      <th>Pihak Yang Melakukan Kunjungan</th>
                      <th>Nama Petugas SLM</th>
                      <th>Merk CCTV</th>
                      <th>Serial Number CCTV</th>                      
                      <th>Kondisi Kamera CCTV/DVR</th>
                      <th>Merk UPS</th>
                      <th>Serial Number UPS</th>
                      <th>Kondisi UPS</th>
                      <th>Tegangan</th>
                      <th>Ground</th>
                      <th>Suhu Ruang</th>
                      <th>Tindakan</th>
                      <th>Spare Part yang Diganti</th>
                      <th>Versi Image</th>
                      <th>Tgl Kunjungan SLM</th>
                      <th>Jam Kunjungan SLM</th>
            <?php
            
            if($role == ROLE_ADMIN)
            {
            ?>
                      <th>Latitude & Longitude</th>
                      <th>Foto Di Lokasi</th>    
            <?php } ?>  
                    </tr>


                    <?php
                    if(!empty($list_laporan_cmRecords))
                    {
                        foreach($list_laporan_cmRecords as $record)
                        {

                      $lokasi = explode(",",$record->latitude_longitude);
                      $latitude_longitude = $lokasi;
                      $hreflokasi = "https://www.google.com/maps/search/?api=1&query=". $latitude_longitude[0] . "," . $latitude_longitude[1];
                    ?>
                    <tr>
            <?php
            
            if($role == ROLE_FLM)
            {
            ?>

                      <td class="text-center">
                  <?php
                      if($record->ket_status == "FLM")
                    {
                   ?>
                      <a class="btn btn-sm btn-primary" href="<?php echo base_url().'editOld4_flm/'.$record->id; ?>"></i>Edit</a>
                  <?php } ?>

                  <?php
                      if($record->ket_status == "SLM")
                    {
                   ?>
                        <form action="<?php echo base_url() ?>approved_laporan_cm_flm" method="POST" id="searchList">
                            <div class="input-group">
                              <input hidden type="text" name="id" value="<?php echo $record->id; ?>"  style="width: 150px;" placeholder="ID"/>
                            <input type="submit"  onclick="return  confirm('do you want to reject Y/N')"  class="btn btn-sm btn-success" value="Approve" />
                            </div>
                        </form>
                        <form action="<?php echo base_url() ?>rejected_laporan_cm_flm" method="POST" id="searchList">
                            <div class="input-group">
                              <input hidden type="text" name="id" value="<?php echo $record->id; ?>"  style="width: 150px;" placeholder="ID"/>
                            <input type="submit"  onclick="return  confirm('do you want to reject Y/N')"  class="btn btn-sm btn-danger" value="Reject" />
                            </div>
                        </form>
                  <?php } ?>
                      </td>
            <?php } ?>

            <?php
            
            if($role == ROLE_SLM)
            {
            ?>
                      <td class="text-center">
                  <?php
                      if($record->ket_status == "FLM")
                    {
                   ?>
                      <a class="btn btn-sm btn-success" href="<?php echo base_url().'editOld4/'.$record->id; ?>"></i>Approve</a>

                  <?php } ?>
                      </td>
            <?php } ?>
                      <td><?php echo $record->status ?></td>  
                      <td><?php echo $record->ket_status ?></td> 
                      <td><?php echo $record->id_atm ?></td>  
                      <td><?php echo $record->wilayah ?></td>   
                      <td><?php echo $record->cabang_pemilik ?></td>   
                      <td><?php echo $record->lokasi ?></td>
                      <td><?php echo $record->jenis_mesin ?></td>  
                      <td><?php echo $record->tipe_mesin ?></td>
                      <td><?php echo $record->serial_mesin ?></td> 
                      <td><?php echo $record->flm ?></td>          
                      <td><?php echo $record->nama_pt_slm ?></td> 
                      <td><?php echo $record->nama_petugas_flm ?></td>   
                      <td><?php echo $record->npp ?></td>
                      <td><?php echo $record->no_tiket ?></td>
                      <td><?php echo $record->keterangan_cm ?></td>  
                      <td><?php echo $record->tgl_kunjungan_flm ?></td>
                      <td><?php echo $record->jam_kunjungan_flm ?></td>  
                      <td><?php echo $record->pihak_yang_melakukan_kunjungan ?></td> 
                      <td><?php echo $record->nama_petugas_slm ?></td>
                      <td><?php echo $record->merk_cctv ?></td> 
                      <td><?php echo $record->serial_number_cctv ?></td> 
                      <td><?php echo $record->kondisi_kamera_cctv_dvr ?></td> 
                      <td><?php echo $record->merk_ups ?></td> 
                      <td><?php echo $record->serial_number_ups ?></td>  
                      <td><?php echo $record->kondisi_ups ?></td>   
                      <td><?php echo $record->tegangan ?></td>
                      <td><?php echo $record->ground ?></td>  
                      <td><?php echo $record->suhu_ruang ?></td>
                      <td><?php echo $record->tindakan ?></td> 
                      <td><?php echo $record->spare_part_yang_diganti ?></td> 
                      <td><?php echo $record->versi_image ?></td> 
                      <td><?php echo $record->tgl_kunjungan_slm ?></td> 
                      <td><?php echo $record->jam_kunjungan_slm ?></td> 
            <?php
            
            if($role == ROLE_ADMIN)
            {
            ?>
                      <td><a href="<?php echo $hreflokasi; ?>" target="_blank" ><?php echo $record->latitude_longitude ?></a></td>
                      <td><a href="<?php echo base_url().'uploads/laporan_cm/'.$record->foto_di_lokasi; ?>" target="_blank" ><?php echo $record->foto_di_lokasi ?></a></td>
            <?php } ?>                       
                    </tr>
                        <?php
                        }
                    }
                    ?>
                  </table>
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/js/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "list_laporan_cmListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>

<script>
  function myFunction(){
    var x = document.getElementById("myDIV");
    if(x.style.display === "none"){
      x.style.display = "block";
    } 
  }
  
</script>
<script>
  $(document).ready(function() {
  $('input[name="jenis_box"]').click(function() 
                                  {
    var value = $(this).val();
    if( value == "text")
    {
      $('#text_box').show();
      $('#tanggal_box').hide();
      $('#case_box').hide();
    }
    else if( value == "tanggal"){
      $('#text_box').hide();
      $('#tanggal_box').show();
      $('#case_box').hide();
    }
    else if( value == "case_status"){
      $('#text_box').hide();
      $('#tanggal_box').hide();
      $('#case_box').show();
    }


  });
});
</script>
    <script>
    $(document).ready(function(){ // Ketika halaman selesai di load
        $('.input-tanggal').datepicker({
            dateFormat: 'yy-mm-dd' // Set format tanggalnya jadi yyyy-mm-dd
        });

        $('#form-tanggal, #form-bulan, #form-tahun').hide(); // Sebagai default kita sembunyikan form filter tanggal, bulan & tahunnya

        $('#filter').change(function(){ // Ketika user memilih filter
            if($(this).val() == '1'){ // Jika filter nya 1 (per tanggal)
                $('#form-bulan, #form-tahun').hide(); // Sembunyikan form bulan dan tahun
                $('#form-tanggal').show(); // Tampilkan form tanggal
            }else if($(this).val() == '2'){ // Jika filter nya 2 (per bulan)
                $('#form-tanggal').hide(); // Sembunyikan form tanggal
                $('#form-bulan, #form-tahun').show(); // Tampilkan form bulan dan tahun
            }else{ // Jika filternya 3 (per tahun)
                $('#form-tanggal, #form-bulan').hide(); // Sembunyikan form tanggal dan bulan
                $('#form-tahun').show(); // Tampilkan form tahun
            }

            $('#form-tanggal input, #form-bulan select, #form-tahun select').val(''); // Clear data pada textbox tanggal, combobox bulan & tahun
        })
      
    })

  </script>
