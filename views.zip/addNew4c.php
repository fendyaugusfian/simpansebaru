<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i> List Laporan CM Management
        <small>Add Laporan CM</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Laporan CM Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>addNew4c" method="post" role="form" enctype='multipart/form-data'>
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                        
                                    <div class="form-group">
                                        <label for="nama_petugas">Nama Petugas FLM (*)</label>
                                        <input required type="nama_petugas_flm" class="form-control" id="nama_petugas_flm" placeholder="nama_petugas_flm" name="nama_petugas_flm"  maxlength="128">
                                    </div>

                                     <div class="form-group">
                                        <label for="npp">NPP (*)</label>
                                        <input required type="npp" class="form-control" id="npp" placeholder="npp" name="npp"  maxlength="128">
                                    </div>

                                     <div class="form-group">
                                        <label for="no_tiket">No Tiket (*)</label>
                                        <input required type="no_tiket" class="form-control" id="no_tiket" placeholder="no_tiket" name="no_tiket"  maxlength="128">
                                    </div>
                                     <div class="form-group">
                                        <label for="keterangan_cm">Keterangan CM (*)</label>
                                        <input required type="keterangan_cm" class="form-control" id="keterangan_cm" placeholder="keterangan_cm" name="keterangan_cm"  maxlength="128">
                                    </div>
                                    <div class="form-group">

                                        <label for="file">Lampirkan Foto ID ATM Mesin Di Lokasi</label>
                                        <br>
                                        <input required type="file" name="foto_di_lokasi" size="20" accept="image/*" capture/>
                                
                                    <br>
                                    </div>
                                        <input hidden type="text" name="id_atm" value="<?php echo $id_atm; ?>"  style="width: 150px;" placeholder="ID ATM"/>
                                        <input hidden type="text" name="wilayah" value="<?php echo $wilayah; ?>"  style="width: 150px;" placeholder="Wilayah"/>
                                        <input hidden type="text" name="cabang_pemilik" value="<?php echo $cabang_pemilik; ?>"  style="width: 150px;" placeholder="Cabang Pemilik"/>
                                        <input hidden type="text" name="lokasi" value="<?php echo $lokasi; ?>"  style="width: 150px;" placeholder="ID ATM"/>
                                        <input hidden type="text" name="jenis_mesin" value="<?php echo  $jenis_mesin; ?>"  style="width: 150px;" placeholder="Jenis Mesin"/>
                                        <input hidden type="text" name="tipe_mesin" value="<?php echo $tipe_mesin; ?>"  style="width: 150px;" placeholder="Tipe Mesin"/>
                                        <input hidden type="text" name="serial_mesin" value="<?php echo $serial_mesin; ?>"  style="width: 150px;" placeholder="Serial Mesin"/>
                                        <input hidden type="text" name="flm" value="<?php echo $flm; ?>"  style="width: 150px;" placeholder="FLM"/>
                                        <input hidden type="text" name="nama_pt_slm" value="<?php echo $nama_pt_slm; ?>"  style="width: 150px;" placeholder="Nama PT SLM"/>
                                        <input hidden type="text" name="latitude_longitude" value="<?php echo $latitude_longitude; ?>"  style="width: 150px;" placeholder="Latitude Longitude"/>
                                </div>
                            </div>
                                    
                            <input type="submit" class="btn btn-primary" value="Submit" />
                        </div><!-- /.box-body -->
    

                    </form>

            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>
<script src="<?php echo base_url(); ?>assets/js/addlist_atm.js" type="text/javascript"></script>
