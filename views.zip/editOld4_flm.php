<?php
if(!empty($list_laporan_cmInfo))
{
    foreach ($list_laporan_cmInfo as $v_ri)
    {
        $id=$v_ri->id;    
        $nama_petugas_flm=$v_ri->nama_petugas_flm;
        $npp=$v_ri->npp;
        $no_tiket=$v_ri->no_tiket;
        $keterangan_cm=$v_ri->keterangan_cm;
    }
}
?>
<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/font-awesome.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/smoothness/jquery-ui.css" >
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i> List Laporan CM Management
        <small>Add / Edit List Laporan CM</small>
      </h1>
    </section>
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter List Laporan CM Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>editlist_laporan_cm_flm" method="post" id="editlist_laporan_cm" role="form">
                        <div class="box-body">
                            <div class="row">
                               <div class="col-md-6">                     
                                    <div hidden class="form-group">
                                        <label for="id">List Laporan ID</label>
                                        <br>
                                        <input type="text" class="form-control" id="id" placeholder="id" name="id" value="<?php echo $id; ?>" maxlength="128">
                                    </div>
                                    
            
                                    <div class="form-group">
                                        <label for="nama_petugas_flm">Nama Petugas FLM</label>
                                        <input type="text" class="form-control" id="nama_petugas_flm" placeholder="nama_petugas_flm" name="nama_petugas_flm" value="<?php echo $nama_petugas_flm; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="npp">NPP</label>
                                        <input type="text" class="form-control" id="npp" placeholder="npp" name="npp" value="<?php echo $npp; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="no_tiket">No Tiket</label>
                                        <input type="text" class="form-control" id="no_tiket" placeholder="no_tiket" name="no_tiket" value="<?php echo $no_tiket; ?>" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="keterangan_cm">Keterangan CM</label>
                                        <input type="text" class="form-control" id="keterangan_cm" placeholder="keterangan_cm" name="keterangan_cm" value="<?php echo $keterangan_cm; ?>" maxlength="128">
                                    </div>                                    
                                          
                               </div>
                            </div>
                        </div><!-- /.box-body -->
    
    
                        <div class="box-footer">
                        <a href="<?php echo base_url(); ?>list_laporan_cmListing"> 
                        <button class="btn btn-danger">Back</BUTTON>
                        </a> 
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>

<script src="<?php echo base_url(); ?>assets/js/editUser.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/js/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
    <script>
    $(document).ready(function(){ // Ketika halaman selesai di load
        $('.input-tanggal').datepicker({
            dateFormat: 'yy-mm-dd' // Set format tanggalnya jadi yyyy-mm-dd
        });

        $('#form-tanggal, #form-bulan, #form-tahun').hide(); // Sebagai default klist_laporan_cm sembunyikan form filter tanggal, bulan & tahunnya

        $('#filter').change(function(){ // Ketika user memilih filter
            if($(this).val() == '1'){ // Jika filter nya 1 (per tanggal)
                $('#form-bulan, #form-tahun').hide(); // Sembunyikan form bulan dan tahun
                $('#form-tanggal').show(); // Tampilkan form tanggal
            }else if($(this).val() == '2'){ // Jika filter nya 2 (per bulan)
                $('#form-tanggal').hide(); // Sembunyikan form tanggal
                $('#form-bulan, #form-tahun').show(); // Tampilkan form bulan dan tahun
            }else{ // Jika filternya 3 (per tahun)
                $('#form-tanggal, #form-bulan').hide(); // Sembunyikan form tanggal dan bulan
                $('#form-tahun').show(); // Tampilkan form tahun
            }

            $('#form-tanggal input, #form-bulan select, #form-tahun select').val(''); // Clear data pada textbox tanggal, combobox bulan & tahun
        })
      
    })

  </script>