<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = "login";
$route['404_override'] = 'error';


/*********** USER DEFINED ROUTES *******************/

$route['loginMe'] = 'login/loginMe';
$route['dashboard'] = 'user';
$route['logout'] = 'user/logout';

$route['userListing'] = 'user/userListing';
$route['list_atmListing'] = 'list_atm/list_atmListing';
$route['list_atm_historyListing'] = 'list_atm_history/list_atm_historyListing';
$route['list_laporanListing'] = 'list_laporan/list_laporanListing';
$route['list_laporan_cmListing'] = 'list_laporan_cm/list_laporan_cmListing';
$route['list_laporan_pmListing'] = 'list_laporan_pm/list_laporan_pmListing';

$route['reportListing'] = 'report/reportListing';
$route['aboutListing'] = 'about/aboutListing';

$route['userListing/(:num)'] = "user/userListing/$1";
$route['list_atmListing/(:num)'] = "list_atm/list_atmListing/$1";
$route['list_atm_historyListing/(:num)'] = "list_atm_history/list_atm_historyListing/$1";
$route['list_laporanListing/(:num)'] = "list_laporan/list_laporanListing/$1";
$route['list_laporan_cmListing/(:num)'] = "list_laporan_cm/list_laporan_cmListing/$1";
$route['list_laporan_pmListing/(:num)'] = "list_laporan_pm/list_laporan_pmListing/$1";

$route['addNew'] = "user/addNew";
$route['addNewUser'] = "user/addNewUser";

$route['addNew1'] = "list_atm/addNew1";

$route['addNew3a'] = "list_laporan/addNew3a";
$route['addNew3b'] = "list_laporan/addNew3b";
$route['addNew3c'] = "list_laporan/addNew3c";
$route['addNew3d'] = "list_laporan/addNew3d";
$route['addNew3e'] = "list_laporan/addNew3e";
$route['addNew4a'] = "list_laporan_cm/addNew4a";
$route['addNew4b'] = "list_laporan_cm/addNew4b";
$route['addNew4c'] = "list_laporan_cm/addNew4c";
$route['addNew4d'] = "list_laporan_cm/addNew4d";


$route['upload'] = "list_atm/upload";
$route['formlist_atm'] = "list_atm/formlist_atm";
$route['upload_list_laporan_pm'] = "list_laporan_pm/upload_list_laporan_pm";
$route['formlist_laporan_pm'] = "list_laporan_pm/formlist_laporan_pm";

$route['clearlist_atm'] = "list_atm/clearlist_atm";
$route['clearlist_laporan_pm'] = "list_laporan_pm/clearlist_laporan_pm";

$route['addNewlist_atm'] = "list_atm/addNewlist_atm";
$route['approved_status_atr'] = "list_atm_history/approved_status_atr";
$route['rejected_status_atr'] = "list_atm_history/rejected_status_atr";
$route['approved_status_selesai'] = "list_atm_history/approved_status_selesai";
$route['rejected_status_selesai'] = "list_atm_history/rejected_status_selesai";

$route['approved_laporan_cm_flm'] = "list_laporan_cm/approved_laporan_cm_flm";
$route['rejected_laporan_cm_flm'] = "list_laporan_cm/rejected_laporan_cm_flm";
$route['rejected_laporan_cm_slm'] = "list_laporan_cm/rejected_laporan_cm_slm";
$route['update_id_atm'] = "list_atm_history/update_id_atm";

$route['cek_id_atm'] = "list_laporan/cek_id_atm";
$route['cek_id_atm_cm'] = "list_laporan_cm/cek_id_atm_cm";


$route['editOld'] = "user/editOld";
$route['editOld/(:num)'] = "user/editOld/$1";
$route['editUser'] = "user/editUser";

$route['editOld1'] = "list_atm/editOld1";
$route['editOld2'] = "list_atm/editOld2";

$route['editOld2a'] = "list_laporan/editOld2a";


$route['editOld3'] = "list_laporan/editOld3";
$route['editOld4'] = "list_laporan_cm/editOld4";
$route['editOld4_flm'] = "list_laporan_cm/editOld4_flm";
$route['editOld5'] = "list_laporan_pm/editOld5";
$route['editOld5a'] = "list_laporan_pm/editOld5a";

$route['editOld1/(:num)'] = "list_atm/editOld1/$1";
$route['editOld2/(:num)'] = "list_atm/editOld2/$1";
$route['editOld3/(:num)'] = "list_laporan/editOld3/$1";
$route['editOld4/(:num)'] = "list_laporan_cm/editOld4/$1";
$route['editOld4_flm/(:num)'] = "list_laporan_cm/editOld4_flm/$1";
$route['editOld5/(:num)'] = "list_laporan_pm/editOld5/$1";
$route['editOld5a/(:num)'] = "list_laporan_pm/editOld5a/$1";

$route['editlist_atm'] = "list_atm/editlist_atm";
$route['editlist_atm_2'] = "list_atm/editlist_atm_2";


$route['update_id_atm'] = "list_atm_history/update_id_atm";

$route['editlist_laporan'] = "list_laporan/editlist_laporan";
$route['editlist_laporan_cm'] = "list_laporan_cm/editlist_laporan_cm";
$route['editlist_laporan_cm_flm'] = "list_laporan_cm/editlist_laporan_cm_flm";
$route['editlist_laporan_pm'] = "list_laporan_pm/editlist_laporan_pm";
$route['editlist_laporan_pm_2'] = "list_laporan_pm/editlist_laporan_pm_2";

$route['deleteUser'] = "user/deleteUser";
$route['deletelist_atm'] = "list_atm/deletelist_atm";
$route['deletelist_laporan'] = "list_laporan/deletelist_laporan";
$route['deletelist_laporan_pm'] = "list_laporan_pm/deletelist_laporan_pm";

$route['download_report'] = "report/download_report";

$route['loadChangePass'] = "user/loadChangePass";
$route['changePassword'] = "user/changePassword";
$route['pageNotFound'] = "user/pageNotFound";
$route['checkusernameExists'] = "user/checkusernameExists";

$route['forgotPassword'] = "login/forgotPassword";
$route['resetPasswordUser'] = "login/resetPasswordUser";
$route['resetPasswordConfirmUser'] = "login/resetPasswordConfirmUser";
$route['resetPasswordConfirmUser/(:any)'] = "login/resetPasswordConfirmUser/$1";
$route['resetPasswordConfirmUser/(:any)/(:any)'] = "login/resetPasswordConfirmUser/$1/$2";
$route['createPasswordUser'] = "login/createPasswordUser";

/* End of file routes.php */
/* Location: ./application/config/routes.php */