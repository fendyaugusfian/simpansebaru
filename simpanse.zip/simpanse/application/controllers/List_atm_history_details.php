<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : list_atm_history_details (list_atm_history_detailsController)
 * list_atm_history_details Class to control all list_atm_history_details related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class list_atm_history_details extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('list_atm_history_details_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the list_atm_history_details
     */
    public function index()
    {
        $this->global['pageTitle'] = 'Monitoring list_atm_history_details : Dashboard';
        
        $this->loadViews("dashboard", $this->global, NULL , NULL);
    }
    
    /**
     * This function is used to load the list_atm_history_details list
     */
        function list_atm_history_detailsListing()
    {
    if($this->isAdmin() == FALSE || $this->isATR() == FALSE || $this->isFLM() == FALSE || $this->isSLM() == FALSE  )
        {
            $this->load->model('list_atm_history_details_model');
        
         
            $id_atmText = $this->input->post('id_atmText');
            $data['id_atmText'] = $id_atmText;
            $this->load->library('pagination');
            
            $count = $this->list_atm_history_details_model->list_atm_history_detailsListingCount($id_atmText);
            
            $returns = $this->paginationCompress ( "list_atm_history_detailsListing/", $count, 5 );
            
            $data['list_atm_history_detailsRecords'] = 
            $this->list_atm_history_details_model->list_atm_history_detailsListing($id_atmText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'Monitoring list_atm_history_details : list_atm_history_details Listing';
            
            $this->loadViews("list_atm_history_detailss", $this->global, $data, NULL);
        }
        else
        {
            $this->loadThis();
        }
    }
}

    
   