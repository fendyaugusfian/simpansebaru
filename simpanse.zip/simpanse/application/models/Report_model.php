<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class report_model extends CI_Model
{
    function reportListing($jenis, $tanggalawal, $tanggalakhir, $slm, $wilayah)
    {
    if($_SESSION['roleText'] == "ATR"){
        if ($jenis == 'list_atm'){
        $this->db->select('*');
        $tabel = 'list_atm';
        $this->db->from($tabel);
        $this->db->where('wilayah', $wilayah);
        if ($slm != NULL ){
            $this->db->where('nama_pt_slm',$slm);
        }
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
        }
        if ($jenis == 'list_atm_history'){
        $this->db->select('*');
        $tabel = 'list_atm_history';
        $this->db->from($tabel);
        $this->db->where('wilayah', $wilayah);
        if ($slm != NULL ){
            $this->db->where('nama_pt_slm',$slm);
        }
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
        }

        if ($jenis == 'list_laporan'){
        $this->db->select('*');
        $tabel = 'list_laporan';
        $this->db->from($tabel);
        if ($tanggalawal != NULL && $tanggalakhir != NULL){
        $this->db->where('tgl_kunjungan >=',$tanggalawal);
        $this->db->where('tgl_kunjungan <=',$tanggalakhir);
        }
        $this->db->where('wilayah', $wilayah);
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
        }
        if ($jenis == 'list_laporan_cm'){
        $this->db->select('*');
        $tabel = 'list_laporan_cm';
        $this->db->from($tabel);
        $this->db->where('wilayah', $wilayah);
        if ($tanggalawal != NULL && $tanggalakhir != NULL){
        $this->db->where('tgl_kunjungan >=',$tanggalawal);
        $this->db->where('tgl_kunjungan <=',$tanggalakhir);
        }
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
        }
        if ($jenis == 'list_laporan_pm'){
        $this->db->select('*');
        $tabel = 'list_laporan_pm';
        $this->db->from($tabel);
        $this->db->where('wilayah', $wilayah);
        if ($slm != NULL ){
            $this->db->where('nama_pt_slm',$slm);
        }
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
        }
    }
    else{
        if ($jenis == 'list_atm'){
        $this->db->select('*');
        $tabel = 'list_atm';
        $this->db->from($tabel);

        if ($slm != NULL ){
            $this->db->where('nama_pt_slm',$slm);
        }
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
        }
        if ($jenis == 'list_atm_history'){
        $this->db->select('*');
        $tabel = 'list_atm_history';
        $this->db->from($tabel);
        if ($slm != NULL ){
            $this->db->where('nama_pt_slm',$slm);
        }
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
        }

        if ($jenis == 'list_laporan'){
        $this->db->select('*');
        $tabel = 'list_laporan';
        $this->db->from($tabel);
        if ($tanggalawal != NULL && $tanggalakhir != NULL){
        $this->db->where('tgl_kunjungan >=',$tanggalawal);
        $this->db->where('tgl_kunjungan <=',$tanggalakhir);
        }
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
        }
        if ($jenis == 'list_laporan_cm'){
        $this->db->select('*');
        $tabel = 'list_laporan_cm';
        $this->db->from($tabel);
        if ($tanggalawal != NULL && $tanggalakhir != NULL){
        $this->db->where('tgl_kunjungan >=',$tanggalawal);
        $this->db->where('tgl_kunjungan <=',$tanggalakhir);
        }
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
        }
        if ($jenis == 'list_laporan_pm'){
        $this->db->select('*');
        $tabel = 'list_laporan_pm';
        $this->db->from($tabel);
        if ($slm != NULL ){
            $this->db->where('nama_pt_slm',$slm);
        }
        $query = $this->db->get();
        $result = $query->result();        
        return $result;
        }
    }
}
}

  